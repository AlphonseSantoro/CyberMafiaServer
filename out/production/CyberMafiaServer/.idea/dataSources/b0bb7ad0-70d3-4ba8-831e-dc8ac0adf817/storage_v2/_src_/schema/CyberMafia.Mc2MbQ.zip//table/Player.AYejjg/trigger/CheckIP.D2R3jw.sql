CREATE TRIGGER CheckIP
  AFTER INSERT
  ON Player
  FOR EACH ROW
  INSERT INTO ip_list
VALUES (new.playerIP, new.username, null);

